// Denis Loren Moldovan, Jorge Adrian Saghin Dudulea, Gr. 121
// 100522240@alumnos.uc3m.es, 100522257@alumnos.uc3m.es
(setq base 2)
(setq limite 8)
(setq i 0)
(setq suma 0)
(defun main ()
(setf i 0)
(setf suma 0)
(loop while (< i limite) do
(setf suma (+ suma base))
(setf i (+ i 1)))
(if (> suma 10)
(print "suma grande")
(print "suma pequena"))
(princ suma))
(main)
